alter table receipt_table 
modify column idreceipt INT Not Null Auto_Increment;

alter table receipt_table auto_increment = 1;

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Gcash', 'Apple', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Maya', 'Orange', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Maya', 'Piatos', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Gcash', 'OrangeAndLemons', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Maya', 'AlingJunisya', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Gcash', 'Markiplier', Now());

insert into receipt_table (idreceipt, vendor, reference, datetime)
values (null, 'Maya', 'JacksepticEye', Now());