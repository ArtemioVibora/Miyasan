create table receipt_table (
	idreceipt int,
	vendor varchar(45),
    ref varchar(45),
    date_time datetime(0)
);