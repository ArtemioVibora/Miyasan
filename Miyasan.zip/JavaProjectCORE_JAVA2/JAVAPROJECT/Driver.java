

public class Driver {

    //March 31, 12:12 am
    //To Do: Going to parse the JSON file first and txt file
    //Projected time of finishing this project is approx 2 days
    //Will begin this tomorrow 6pm.

    //March 31, 12:59 pm
    //Commencing Jackson.core/annotations/and databind to this project
    //Now we can generate files with ease.

    public static void main(String[] args) {
        App app = new App(2);

        app.CommandLine();
    }
}
